package com.jarvis.system

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var prefs: JarvisPrefs
    private lateinit var apiClient: JarvisApiClient
    private lateinit var voiceManager: JarvisVoiceManager
    private lateinit var deviceController: JarvisDeviceController

    private lateinit var tvStatus: TextView
    private lateinit var tvChatLog: TextView
    private lateinit var scrollChat: ScrollView
    private lateinit var etInput: EditText
    private lateinit var btnOverlayOrb: Button
    private lateinit var btnAwayMode: Button
    private lateinit var btnLang: Button

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    private val roleLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = JarvisPrefs(this)
        apiClient = JarvisApiClient(this)
        voiceManager = JarvisVoiceManager(this, apiClient)
        deviceController = JarvisDeviceController(this)

        tvStatus = findViewById(R.id.tvStatus)
        tvChatLog = findViewById(R.id.tvChatLog)
        scrollChat = findViewById(R.id.scrollChat)
        etInput = findViewById(R.id.etInput)
        btnOverlayOrb = findViewById(R.id.btnOverlayOrb)
        btnAwayMode = findViewById(R.id.btnAwayMode)
        btnLang = findViewById(R.id.btnLang)

        requestRuntimePermissions()
        refreshButtons()
        appendChat("Jarvis", "নমস্কার! আমি এখন আপনার Android ফোনে সিস্টেম মোডে প্রস্তুত। নিচের মাইকে কথা বলুন অথবা ভাসমান অর্ব চালু করুন।")

        findViewById<Button>(R.id.btnSend).setOnClickListener { submitInput() }

        etInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                submitInput()
                true
            } else {
                false
            }
        }

        findViewById<Button>(R.id.btnMic).setOnClickListener {
            voiceManager.startSingleListen(
                onListening = { tvStatus.text = "শুনছি…" },
                onResult = { spoken -> sendTurn(spoken) },
                onError = { err -> tvStatus.text = err }
            )
        }

        btnLang.setOnClickListener {
            prefs.language = if (prefs.language == "bn-BD") "en-US" else "bn-BD"
            refreshButtons()
        }

        findViewById<Button>(R.id.btnServer).setOnClickListener {
            showServerUrlDialog()
        }

        btnOverlayOrb.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                return@setOnClickListener
            }
            val serviceIntent = Intent(this, JarvisOverlayService::class.java)
            if (JarvisOverlayService.isRunning) {
                stopService(serviceIntent)
                JarvisOverlayService.isRunning = false
            } else {
                ContextCompat.startForegroundService(this, serviceIntent)
                JarvisOverlayService.isRunning = true
            }
            refreshButtons()
        }

        btnAwayMode.setOnClickListener {
            val next = !prefs.awayEnabled
            prefs.awayEnabled = next
            refreshButtons()
            CoroutineScope(Dispatchers.Main).launch {
                apiClient.syncAwayEnabled(next)
            }
        }

        findViewById<Button>(R.id.btnPermsOverlay).setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        findViewById<Button>(R.id.btnPermsNotif).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        findViewById<Button>(R.id.btnPermsCallScreen).setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val rm = getSystemService(RoleManager::class.java)
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) {
                    roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
                    return@setOnClickListener
                }
            }
            startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
        }

        findViewById<Button>(R.id.btnPermsAssist).setOnClickListener {
            startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
        }

        findViewById<Button>(R.id.btnQuickBrief).setOnClickListener {
            sendTurn(
                if (prefs.language == "bn-BD")
                    "আমাকে আজকের সংক্ষিপ্ত খবর ও আবহাওয়ার ব্রিফিং দাও।"
                else
                    "Give me a quick briefing on today's news and weather."
            )
        }

        findViewById<Button>(R.id.btnQuickTorch).setOnClickListener {
            val on = deviceController.toggleFlashlight()
            appendChat("Jarvis", if (on) "ফ্ল্যাশলাইট চালু করেছি।" else "ফ্ল্যাশলাইট বন্ধ করেছি।")
        }

        findViewById<Button>(R.id.btnQuickBattery).setOnClickListener {
            val pct = deviceController.getBatteryPercent()
            appendChat("Jarvis", "আপনার ফোনে এখন $pct% চার্জ আছে।")
        }
    }

    override fun onResume() {
        super.onResume()
        refreshButtons()
    }

    private fun submitInput() {
        val text = etInput.text.toString().trim()
        if (text.isNotBlank()) {
            etInput.setText("")
            sendTurn(text)
        }
    }

    private fun showServerUrlDialog() {
        val input = EditText(this).apply {
            setText(prefs.serverUrl)
            setTextColor(0xFFFFFFFF.toInt())
        }
        AlertDialog.Builder(this)
            .setTitle("Jarvis Backend Server URL")
            .setView(input)
            .setPositiveButton("সেভ করুন") { _, _ ->
                prefs.serverUrl = input.text.toString()
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun sendTurn(text: String) {
        appendChat("আপনি", text)
        tvStatus.text = "ভাবছি…"
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val reply = apiClient.askJarvis(text)
                appendChat("Jarvis", reply)
                tvStatus.text = "বলছি…"
                voiceManager.speak(reply) {
                    tvStatus.text = "প্রস্তুত"
                }
            } catch (e: Exception) {
                appendChat("Error", e.message ?: "Request failed")
                tvStatus.text = "প্রস্তুত"
            }
        }
    }

    private fun appendChat(who: String, msg: String) {
        val current = tvChatLog.text.toString()
        val line = "[$who]\n$msg\n\n"
        tvChatLog.text = current + line
        scrollChat.post { scrollChat.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun refreshButtons() {
        btnLang.text = if (prefs.language == "bn-BD") "English" else "বাংলা"
        btnOverlayOrb.text = if (JarvisOverlayService.isRunning) "ভাসমান অর্ব বন্ধ" else "ভাসমান অর্ব চালু"
        btnAwayMode.text = if (prefs.awayEnabled) "অবর্তমান অটো-রিপ্লাই: চালু" else "অবর্তমান অটো-রিপ্লাই: বন্ধ"
    }

    private fun requestRuntimePermissions() {
        val needed = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CAMERA
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permLauncher.launch(missing.toTypedArray())
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceManager.destroy()
    }
}
