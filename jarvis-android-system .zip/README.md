# Jarvis System Assistant (Android APK)

Native Android system-level assistant connected to your **Jarvis Live** backend.

## Included System Features
- **Floating System Orb + On-Screen Bubble** (`SYSTEM_ALERT_WINDOW` + Foreground Service) — stays draggable over every app and shows live status & replies right on screen.
- **Default Digital Assistant** (`android.intent.action.ASSIST`) — trigger Jarvis from your phone's assistant gesture or power-button long press.
- **Away Auto-Reply Service** (`NotificationListenerService`) — reads incoming WhatsApp / SMS / Messenger / Telegram notifications when Away Mode is ON and sends human-like replies automatically via `RemoteInput`.
- **Incoming Call Screener** (`CallScreeningService`) — logs incoming calls while away and records caller numbers.
- **Smart Contact Lookup** — automatically resolves contact names from your Android phonebook when calling or sending SMS / WhatsApp.
- **Device Control** — Flashlight toggle, launch installed apps by name, battery check, system timers & alarms, Wi-Fi/Bluetooth settings, direct dial & SMS.
- **Natural AI Voice + Bengali/English Speech Recognition** — speaks with Gemini 3.8 natural audio via your backend with device TTS fallback.

## Build APK Using GitHub Actions (No PC Required)
1. Create a new GitHub repository and upload all files from this ZIP (keep the `.github/workflows/build-apk.yml` folder intact).
2. Open the **Actions** tab in your GitHub repository.
3. Wait 2–3 minutes for **Build Jarvis Android APK** to finish.
4. Download the **Jarvis-System-APK** artifact (`app-debug.apk`) directly on your Android phone and install it.
5. Open **Jarvis System**, allow Microphone/Phone/Contacts/Camera permissions, and tap the permission buttons to enable **Overlay Orb**, **Notif Access**, **Call Screen**, and **Assistant**.
